# BloodsoulView
自定义View系列

1.线性变换颜色的TextView

2.流式布局

3.OutTouchViewGroup 设置子View外部点击事件

4.圆形图片

5.上下滚动的条形图片（拆分动画）

6.自定义走马灯效果

7.lottie动画

8.TextView不同颜色文字效果（不能用用一个Span）

9.系统字体

10.圆形Indicator

11.ImageView 高斯模糊效果

12.loading效果的 Dialog

13.LoopViewPager 可循环切换

14.录制准备页的进度动效

15.录制中调节音量的调节器View

16.获取线性变化颜色中的某一点

17.MagicIndicator

18.转盘游戏

19.表情

20.ClickSpannable导致的上层View点击事件无效