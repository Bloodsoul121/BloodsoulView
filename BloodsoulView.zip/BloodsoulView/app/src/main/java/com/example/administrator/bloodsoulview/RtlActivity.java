package com.example.administrator.bloodsoulview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RtlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtl);
    }
}
