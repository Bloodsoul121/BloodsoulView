package com.example.administrator.bloodsoulview.viewpager.pager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.administrator.bloodsoulview.R;

public class PagerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pager);
    }
}
