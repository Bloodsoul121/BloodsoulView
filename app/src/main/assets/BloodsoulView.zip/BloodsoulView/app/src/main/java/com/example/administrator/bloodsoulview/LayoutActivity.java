package com.example.administrator.bloodsoulview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class LayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout);
    }
}
