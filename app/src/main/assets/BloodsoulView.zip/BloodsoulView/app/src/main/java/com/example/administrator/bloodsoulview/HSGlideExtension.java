package com.example.administrator.bloodsoulview;

import com.bumptech.glide.annotation.GlideExtension;

@GlideExtension
public class HSGlideExtension {

    private HSGlideExtension() {
    }
}
